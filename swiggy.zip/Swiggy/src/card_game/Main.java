package card_game;

import components.GamePlay;

public class Main {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		GamePlay gp = new GamePlay();
        gp.playGame();

	}

}
