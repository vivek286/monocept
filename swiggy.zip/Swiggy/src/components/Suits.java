package components;

public enum Suits {
	HEARTS, SPADES, CLUBS, DIAMONDS
}
